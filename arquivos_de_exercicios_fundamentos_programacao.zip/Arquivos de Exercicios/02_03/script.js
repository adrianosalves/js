var nome = prompt("Qual é o seu nome?");
alert("Olá, " + nome + "!");