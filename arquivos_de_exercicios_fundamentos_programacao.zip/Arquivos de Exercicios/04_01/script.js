var a = 10000; 
var b = 1;
  
if (a != b) {
   var mensagem = "a não é igual a b";
   alert(mensagem);
}

b = 10000;

if (a == b) {
  var mensagem = "a é igual a b";
  alert(mensagem);
}