var a = 123; 
var b = "123"; 

if (a === b) {
    alert("a é igual a b");
} 