// Parte 1

function somarNumeros() {

    var a = 5; 
    var b = 10; 

    var soma = a + b;

    alert("A soma é: " + soma);
}

somarNumeros();
somarNumeros();
somarNumeros();

// Parte 2

function somarDoisNumeros(a,b) {

    var soma = a + b;

    alert("A soma é: " + soma);
}

somarDoisNumeros(14,234);
somarDoisNumeros(2,-3);
somarDoisNumeros(0.5,0.23);