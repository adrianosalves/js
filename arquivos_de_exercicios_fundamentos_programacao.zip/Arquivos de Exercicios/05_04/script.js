var soma;

function somarDoisNumeros(a,b) {
     
     soma = a + b;

     return soma; 
}

somarDoisNumeros(10,20);
 
alert(soma); 
