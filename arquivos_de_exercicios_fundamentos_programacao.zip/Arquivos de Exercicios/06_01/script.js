var a = 1;

while ( a < 10 ) {
     alert(a);
     a++;
} 

// Mais código