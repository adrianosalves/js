var quantidade = 0;

// Índice para contar as iterações
var i = 1;

// Loop - verifica condição
while (i  < 10) {
     quantidade += 100;

     // Atualizar índice
     i++;
}

alert("A quantidade depois do while é: " + quantidade);