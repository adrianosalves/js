// Parte 1 

var a = "Olá";
var b = "olá";

if ( a == b ) {
     alert("a é igual a b");
} 
else {
     alert("a é diferente de b");
}

// Parte 2

var a = "Olá";
var b = "olá";

if ( a < b ) {
     alert(a + " vem antes de " + b);
} 
else {
     alert(a + " vem depois de " + b);
}

// Parte 3

var a = "Olá";
var b = "10 olás";

if ( a < b ) {
     alert(a + " vem antes de " + b);
} 
else {
     alert(a + " vem depois de " + b);
}

// Parte 4

var a = "#Olá";
var b = "10 olás";

if ( a < b ) {
     alert(a + " vem antes de " + b);
} 
else {
     alert(a + " vem depois de " + b);
}

// Parte 5

var a = "Olá";
var b = "olá";

if ( a.toLowerCase() == b.toLowerCase() ) {
     alert(a + " é igual a " + b);
} 
else {
     alert(a + " não é igual a " + b);
}