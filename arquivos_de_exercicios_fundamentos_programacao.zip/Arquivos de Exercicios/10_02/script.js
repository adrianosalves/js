var titulo = document.getElementById("tituloPrincipal");
titulo.innerHTML = "Esse é um novo título!";