var titulo = document.getElementById("tituloPrincipal");
titulo.onclick = function() {
  titulo.innerHTML = "O título foi clicado!"
};