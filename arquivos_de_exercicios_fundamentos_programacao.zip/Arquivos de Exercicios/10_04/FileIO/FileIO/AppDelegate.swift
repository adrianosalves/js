//
//  AppDelegate.swift
//  FileIO
//
//  Created by Lucas Longo on 12/17/18.
//  Copyright © 2018 Lucas Longo. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

