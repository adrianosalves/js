var x = 1; 
var y = 10; 
var z = 100;

var max = Math.max(x,y,z);

max = new String("5,6,7,8");;
alert(max);

